<?php
include'functions.php';
add_user();
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->

    <head>
        <meta charset="utf-8" />
        <title>CollaBty Login Page</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="CollaBty " name="description" />
        <meta content="OmarSabet.net" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="assets/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="assets/global/css/components-md.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="assets/global/css/plugins-md.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN PAGE LEVEL STYLES -->
        <link href="assets/layouts/layout/css/themes/darkblue.css" rel="stylesheet" type="text/css"/>
        <link href="assets/pages/css/login-2.css" rel="stylesheet" type="text/css" />
        <link href="css/custom.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> </head>
    <!-- END HEAD -->

<body class="login" data-overlay="0.7">
    <!-- Signin With FACEBOOK init -->
            <div id="fb-root"></div>
            <script>(function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&autoLogAppEvents=1&version=v2.12&appId=1615689645399524';
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>

        <!-- BEGIN LOGO -->
        <div class="logo">
            <a href="index.php">
                <img src="img/logo-white.png" style="height: 70px;" alt="" /> </a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN LOGIN -->
        <div class="content">
            <!-- BEGIN LOGIN FORM -->
            <form class="login-form slide-in-fwd-center" action="index.html" method="post">
                <div class="form-title">
                    
                </div>
                <div class="alert alert-danger display-hide">
                    <button class="close" data-close="alert"></button>
                   
                </div>
                
               
           
            <!-- END FORGOT PASSWORD FORM -->
            <!-- BEGIN REGISTRATION FORM -->
           
           
                <form class="interests-form fade-in-right" action="">
                    <p class="hint text-center"> Choose your interests below (max 5): pick atleast 2 so get inspired, collaborate and connect</p>
                            <div class="form-group">
                                <ul class="interests">
                                  <li><input type="checkbox" id="cb1" />
                                    <label for="cb1"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb2" />
                                    <label for="cb2"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb3" />
                                    <label for="cb3"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb4" />
                                    <label for="cb4"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb5" />
                                    <label for="cb5"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb6" />
                                    <label for="cb6"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb7" />
                                    <label for="cb7"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb8" />
                                    <label for="cb8"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb9" />
                                    <label for="cb9"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb10" />
                                    <label for="cb10"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb11" />
                                    <label for="cb11"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb12" />
                                    <label for="cb12"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb13" />
                                    <label for="cb13"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb14" />
                                    <label for="cb14"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                  <li><input type="checkbox" id="cb15" />
                                    <label for="cb15"><img src="http://placehold.it/100x100" /></label>
                                  </li>
                                </ul>
                            </div>
                 <div class="form-actions">
                    <button type="button" id="interests-back-btn" class="btn green btn-default">Back</button>
                    <button type="submit" id="interests-submit-btn" class="btn uppercase red pull-right">Submit</button>
                </div>
            </form>
            <!-- END REGISTRATION FORM -->
        </div>
        <div class="copyright"> 2018 © Collabty. Social Collaboration Platform. </div>
        <!-- END LOGIN -->
        <!--[if lt IE 9]>
<script src="assets/global/plugins/respond.min.js"></script>
<script src="assets/global/plugins/excanvas.min.js"></script> 
<script src="assets/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="assets/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
       <script src="assets/pages/scripts/components-select2.js" type="text/javascript"></script>
       <script src="assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>
        <script src="assets/pages/scripts/login.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <!-- END THEME LAYOUT SCRIPTS -->
    </body>

</html>