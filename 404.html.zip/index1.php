

<?php

include'functions.php';

if(!isset($_SESSION['user']))
{
    header('Location: signup.php');
}
else{
    $user_id = $_SESSION['user'];
    $user_data = get_user_data($user_id);
    $data = $user_data->fetch_assoc();











   
    $user_profile = get_profile_data($user_id);
    if ($user_profile != "NO") 
    {
        
        $profile = $user_profile->fetch_assoc();
        $profile_pic = $profile['profile_pic'];
        $cover_pic =  $profile['cover_pic'];
        $user_brief = $profile['brief'];
        $facebook=$profile['facebook'];
        $instagram=$profile['instagram'];
        $twitter=$profile['twitter'];
        $pintrest=$profile['pintrest'];
        $dribble=$profile['dribble'];
        $linkedin=$profile['linkedin'];
        $soundcloud=$profile['soundcloud'];
        $behance=$profile['behance'];
        $youtube=$profile['youtube'];

        $array=Array();




       
      

    }




}
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->

    <head>
        <meta charset="utf-8" />
        <title>CollaBty - Collaboration community and platform </title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta name="author" content="OmarSabet.net">
        <meta name="description" content="CollaBty is a collaboration platform for all kinds of skills, matching users together to create  something beautiful">
        <meta name="keywords" content="social media, social network, collab, projects, platform, sharing, skills, interests">
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Raleway:400,500,600,700&subset=all" type="text/css" />
        <link href="assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/socicon/socicon.css" rel="stylesheet" type="text/css" />

        <link href="assets/global/plugins/bootstrap-modal/css/bootstrap-modal-bs3patch.css" rel="stylesheet" type="text/css">
        <link href="assets/global/plugins/bootstrap-modal/css/bootstrap-modal.css" rel="stylesheet" type="text/css">
        <link href="assets/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/global/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
          
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="assets/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="assets/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="assets/layouts/layout3/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/layouts/layout3/css/themes/green-haze.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <!-- END THEME LAYOUT STYLES -->
    
    <!-- ==== Plugins Bundle ==== -->
    <link rel="stylesheet" href="css/plugins.min.css">
    <!-- ==== Main Stylesheet ==== -->
    <link rel="stylesheet" href="css/style.css">
    <!-- ==== Responsive Stylesheet ==== -->
    <link rel="stylesheet" href="css/responsive-style.css">
    <!-- ==== Color Scheme Stylesheet ==== -->
    <link rel="stylesheet" href="css/colors/color-7.css">
    <!-- ==== Custom Stylesheet ==== -->
    <link rel="stylesheet" href="css/custom.css">

    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="icon" href="favicon.png" type="image/png" />
    <!-- ==== HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries ==== -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-md page-header-top-fixed">
           <!-- Preloader Start -->
    <div id="preloader">
        <div class="preloader--inner"></div>
    </div>
    <!-- Preloader End -->
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">

                 <?php
                    include'inc/header.php';
                      ?>
                   
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
                        <!-- BEGIN CONTENT -->
                        <div class="page-content-wrapper">
                            <!-- BEGIN CONTENT BODY -->
 <div class="cover--header text-center bg--img" data-overlay="0.75" data-overlay-color="white" data-rjs="2" style="background-image: url('images/profile/covers/<?php echo $cover_pic; ?>');">
            <div class="container">
                <a href="network.php" class="profile-counter following-counter tooltips" data-original-title="Following" data-toggle="tooltip" data-placement="bottom">
                                                <div class="circle" >300</div>
                 </a>
                <div class="cover--avatar online" data-overlay="0.5" data-overlay-color="#EFF3F8">
                    <img src="images/profile/pictures/<?php echo $profile_pic;?>" alt="">
                </div>
                <a href="network.php" class="profile-counter followed-counter tooltips"  data-original-title="Follows" data-toggle="tooltip" data-placement="bottom">
                                                <div class="circle">253</div>
                                                
                 </a>

                <div class="cover--user-name">
                    <h2 class="h2 fw--600"><?php echo $data['username']; ?></h2>
                </div>
                       <?php

                        $result = get_categories();
                        if ($result != "NO")
                        {
                            $skillsarray=Array();
                            while ($row = $result->fetch_assoc()) {
                                $cat_name = $row['category'];
                                $cat_id = $row['id'];
                               
                                $result2 = get_skills($cat_id);
                                while ($get = $result2->fetch_assoc()) {

                                    $skill_name = $get['skill'];
                                   
                                    $skill_id = $get['id'];
                                    $check_skill = 0;
                                    $result3 = get_user_skills($user_id);
                                     while ($uskill = $result3->fetch_assoc()) {
                                         if ($skill_id == $uskill['skill_id'])
                                         {
                                             $check_skill = 1;
                                              array_push($skillsarray, $skill_name);
                                             
                                         }
                                     }
                                     
                                }
                                
                            }
                        }
                        
                    ?>

                <div class="cover--user-name">
                    <h2 class="h3 fw--600"> 
                      <?php


                                                for($i=0;$i<count($skillsarray);$i++)
                                                {
                                                    echo $skillsarray[$i];
                                                    if($i<count($skillsarray)-1)
                                                    {
                                                       echo "/"; 
                                                    }
                                                    
                                                    
                                                }
                                                ?>

                    
                </div>

                

                <div class="cover--user-desc fw--400 fs--18 fstyle--i text-darkest">
                    <p><?php echo $user_brief;?></p>
                </div>
                
            <div class="btn-group btn-group-circle cover--user-desc">
                        <button type="button" class="btn btn-default dark-purple" onclick="location.href='edit-profile.php';">
                            <i class="fa fa-user"></i> Edit Profile</button>
                        <button type="button" class="btn btn-default dark-purple">
                            <i class="fa fa-envelope"></i> Message</button>
                         <button type="button" class="btn btn-default dark-purple">
                            <i class="fa fa-bullhorn"></i> Follow</button> 
                            <button type="button" class="btn btn-default red btn-circle-right">
                                <i class="fa fa-money"></i> Start Collab </button>
              </div>

          


              <?php

              if($data['username']!=$_SESSION['username'])
              {
                ?>
              <div class="btn-group btn-group-circle cover--user-desc">
                        <button type="button" class="btn btn-default dark-purple hire-button">
                            <i class="fa fa-money"></i> Hire </button>
                        <button type="button" class="btn btn-default dark-purple">
                            <i class="fa fa-envelope"></i> Message</button>
                        <button type="button" class="btn btn-default dark-purple">
                            <i class="fa fa-bullhorn"></i> Follow</button>
                            <button type="button" class="btn btn-default red btn-circle-right">
                                <i class="fa fa-money"></i> Invite to Collab </button>
              </div>
              <?php

              }
               ?>
              
             <div class="socicons cover--user-social">
                                
                                <?php
                                 if (!empty($facebook))
                                 {
                                    ?>
                                    <a href="<?php echo $facebook;?>" target="blank" class="socicon-btn socicon-btn-circle socicon-facebook tooltips" data-original-title="Facebook"></a>
                                    <?php


                                 } 
                                ?>

                                <?php
                                 if (!empty($instagram))
                                 {
                                    ?>
                                    <a href="<?php echo $instagram;?>" target="blank"class="socicon-btn socicon-btn-circle socicon-instagram tooltips" data-original-title="Instagram"></a>
                                    <?php


                                 } 
                                ?>

                                <?php
                                 if (!empty($twitter))
                                 {
                                    ?>
                                    <a href="<?php echo $twitter;?>" target="blank" class="socicon-btn socicon-btn-circle socicon-twitter tooltips" data-original-title="twitter"></a>
                                    <?php


                                 } 
                                ?>

                                <?php
                                 if (!empty($pintrest))
                                 {
                                    ?>
                                    <a href="<?php echo $pintrest;?>" target="blank" class="socicon-btn socicon-btn-circle socicon-pinterest tooltips" data-original-title="pintrest"></a>
                                    <?php


                                 } 
                                ?>

                                <?php
                                 if (!empty($dribble))
                                 {
                                    ?>
                                    <a href="<?php echo $dribble;?>" target="blank" class="socicon-btn socicon-btn-circle socicon-dribbble tooltips" data-original-title="dribble"></a>
                                    <?php


                                 } 
                                ?>

                                <?php
                                 if (!empty($linkedin))
                                 {
                                    ?>
                                    <a href="<?php echo $linkedin;?>" target="blank" class="socicon-btn socicon-btn-circle socicon-linkedin tooltips" data-original-title="linkedin"></a>
                                    <?php


                                 } 
                                ?>
                                <?php
                                 if (!empty($soundcloud))
                                 {
                                    ?>
                                    <a href="<?php echo $soundcloud;?>" target="blank" class="socicon-btn socicon-btn-circle socicon-soundcloud tooltips" data-original-title="soundcloud"></a>
                                    <?php


                                 } 
                                ?>
                                <?php
                                 if (!empty($behance))
                                 {
                                    ?>
                                    <a href="<?php echo $behance;?>" target="blank" class="socicon-btn socicon-btn-circle socicon-behance tooltips" data-original-title="behance"></a>
                                    <?php


                                 } 
                                ?>
                                <?php
                                 if (!empty($youtube))
                                 {
                                    ?>
                                    <a href="<?php echo $youtube;?>" target="blank" class="socicon-btn socicon-btn-circle socicon-youtube tooltips" data-original-title="youtube"></a>
                                    <?php


                                 } 
                                ?>





                                
                </div>
            </div>
        </div>
                            <!-- BEGIN PAGE CONTENT BODY -->
                            <div class="page-content">
                                <div class="container">
                                    <!-- BEGIN PAGE CONTENT INNER -->
                                    <div class="page-content-inner">
     
      <section class="page--wrapper pb--20">
            <div class="container">
                <div class="row">
                    <!-- Main Content Start -->
                    <div class="main--content col-md-9 pb--60" data-trigger="stickyScroll">
                        <div class="main--content-inner drop--shadow">
                            <!-- Content Nav Start -->
                            <div class="content--nav pb--20">
                                <ul class="nav ff--primary fs--14 fw--500 bg-lighter">
                                    <li class="active"><a href="index.php">Feed</a></li>
                                    <li><a href="index-collabs.php">Collaborations</a></li>
                                    <li><a href="index-portfolio.php">Portfolio</a></li>
                                    <li><a href="index-blog.php">Blog</a></li>
                                    <li><a href="index-saved.php">Inspiration</a></li>
                                    <li><a href="index-about.php">About</a></li>
                                </ul>
                            </div>
                            <!-- Content Nav ENd -->

                     <?php
                    include'inc/feed-post.php';
                      ?>
                            <!-- Filter Nav Start -->
                            <div class="filter--nav pb--20 clearfix">
                                <div class="filter--options float--right">
                                    <label>
                                        <span class="fs--14 ff--primary fw--500 text-darker">Show By :</span>

                                        <select name="activityfilter" class="form-control form-sm" data-trigger="selectmenu">
                                            <option value="everything" selected>— Everything —</option>
                                            <option value="media">Media</option>
                                            <option value="collaborations">Collaborations</option>
                                            <option value="blogposts">Blogs</option>
                                            <option value="events">Events</option>
                                        </select>
                                    </label>
                                </div>
                            </div>
                            <!-- Filter Nav End -->

                            <!-- Activity List Start -->
                            <div class="activity--list">
                                <!-- Activity Items Start -->
                                <ul class="activity--items nav">
                                    <li>
                                       <!-- Activity Item Start -->
                                        <div class="activity--item">
                                            <div class="activity--avatar">
                                                <a href="member-activity-personal.html">
                                                    <img src="img/activity-img/avatar-06.jpg" alt="">
                                                </a>
                                            </div>

                                            <div class="activity--info fs--14">
                                                <div class="activity--header">
                                                    <p><a href="member-activity-personal.html">Bonnie P. Rock</a> posted an update</p>
                                                </div>

                                                <div class="activity--meta fs--12">
                                                    <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                </div>
                                                 <div class="reply text-darker float--right" >
                                                        <a href="#" class="btn btn-default" id="Replyshowarea">Reply</a>
                                                    </div>

                                                    <button class="btn btn-default pull-right" id="Replytextarea-ok" name="ok" type="button" value="X">CLOSE</button>

                                                <div class="activity--content">
                                                    <p>Hello friends!</p>
                                                </div>
                                                <div class="col-md-7 textarea pt--20">
                                                    <textarea id="Replytextarea" name="reply"></textarea>
                                            </div>
                                            </div>
                                           
                                        </div>
                                        <!-- Activity Item End -->
                                    </li>
                                    <li>
                                        <!-- Activity Item Start -->
                                        <div class="activity--item">
                                            <div class="activity--avatar">
                                                <a href="member-activity-personal.html">
                                                    <img src="img/activity-img/avatar-02.jpg" alt="">
                                                </a>
                                            </div>

                                            <div class="activity--info fs--14">
                                                <div class="activity--header">
                                                    <p><a href="member-activity-personal.html">Samuel C. Azevedo</a> posted an update in the group <a href="group-home.html">Travel Guides</a></p>
                                                </div>

                                                <div class="activity--meta fs--12">
                                                    <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                </div>

                                                <div class="activity--content">
                                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration  If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything.</p>
                                                </div>

                                                <div class="activity--action fw--700">
                                                    <a href="#">See More...</a>
                                                </div>
                                                 <div class="activity--toolbar">
                                                    <ul class="nav navbar-nav">

                                                        <li><a href="#">Inspiration</a></li>
                                                        <li><a href="#">Like</a></li>
                                                        <li><a href="#">Comment</a></li>
                                                        <li><a href="#">Delete</a></li>
                                                    </ul>
                                                </div>
                                            </div>

                                        </div>
                                        <!-- Activity Item End -->

                                    </li>

                                    <li>
                                        <!-- Activity Item Start -->
                                        <div class="activity--item">
                                            <div class="activity--avatar">
                                                <a href="member-activity-personal.html">
                                                    <img src="img/activity-img/avatar-03.jpg" alt="">
                                                </a>
                                            </div>

                                            <div class="activity--info fs--14">
                                                <div class="activity--header">
                                                    <p><a href="member-activity-personal.html">Denise R. Sherman</a> posted an update in the group <a href="group-home.html">Pet Care</a></p>
                                                </div>

                                                <div class="activity--meta fs--12">
                                                    <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                </div>

                                                <div class="activity--content">
                                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration  If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything.</p>
                                                </div>
                                                
                                                <div class="activity--comments fs--12">
                                                    <ul class="acomment--items nav">
                                                        <li>
                                                            <div class="acomment--item clearfix">
                                                                <div class="acomment--avatar">
                                                                    <a href="member-activity-personal.html">
                                                                        <img src="img/activity-img/avatar-04.jpg" alt="">
                                                                    </a>
                                                                </div>

                                                                <div class="acomment--info">
                                                                    <div class="acomment--header">
                                                                        <p><a href="#">Leticia J. Espinosa</a> Replied</p>
                                                                    </div>

                                                                    <div class="acomment--meta">
                                                                        <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                                    </div>

                                                                    <div class="acomment--content">
                                                                        <p>I also like Pets..... <span style="color: #ec407a;">&hearts; &hearts; &hearts;</span></p>
                                                                    </div>

                                                <div class="activity--toolbar">
                                                    <ul class="nav navbar-nav">
                                                   
                                                        <li><a href="#">Inspiration</a></li>
                                                        <li><a href="#">Like</a></li>
                                                        <li><a href="#">Comment</a></li>
                                                        <li><a href="#">Delete</a></li>
                                                    </ul>
                                                </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Activity Item End -->
                                    </li>
                                    <li>
                                        <!-- Activity Item Start -->
                                        <div class="activity--item">
                                            <div class="activity--avatar">
                                                <a href="member-activity-personal.html">
                                                    <img src="img/activity-img/avatar-05.jpg" alt="">
                                                </a>
                                            </div>

                                            <div class="activity--info fs--14">
                                                <div class="activity--header">
                                                    <p><a href="member-activity-personal.html">Lee E. Jones</a> Shared a link</p>
                                                </div>

                                                <div class="activity--meta fs--12">
                                                    <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                </div>

                                                <div class="activity--content">
                                                    <div class="link--embed">
                                                        <a class="link--url" href="https://www.youtube.com/watch?v=YE7VzlLtp-4" data-trigger="video_popup"></a>

                                                        <div class="link--video">
                                                            <img src="img/activity-img/link-video-poster.jpg" alt="">
                                                        </div>

                                                        <div class="link--info fs--12">
                                                            <div class="link--title">
                                                                <h4 class="h6">There are many variations of passages of Lorem Ipsum available, but the majority have suffered</h4>
                                                            </div>

                                                            <div class="link--desc">
                                                                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing</p>
                                                            </div>

                                                            <div class="link--rel ff--primary text-uppercase">
                                                                <p>www.sss.com</p>
                                                            </div>
                                                        </div>
                                                        <div class="activity--toolbar">
                                                    <ul class="nav navbar-nav">
                                                        
                                                        <li><a href="#">Inspiration</a></li>
                                                        <li><a href="#">Like</a></li>
                                                        <li><a href="#">Comment</a></li>
                                                        <li><a href="#">Delete</a></li>
                                                    </ul>
                                                </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Activity Item End -->
                                    </li>
                                    <li>
                                         <!-- Activity Item Start -->
                                        <div class="activity--item">
                                            <div class="activity--avatar">
                                                <a href="">
                                                    <img src="img/activity-img/avatar-01.jpg" alt="">
                                                </a>
                                            </div>

                                            <div class="activity--info fs--14">
                                                <div class="activity--header">
                                                    <p><a href="member-activity-personal.html">Eileen K. Ruiz</a> update her profile picture</p>
                                                </div>

                                                <div class="activity--meta fs--12">
                                                    <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                </div>

                                                <div class="activity--content">
                                                    <div class="img--embed"  data-trigger="zoom">
                                                        <img src="img/activity-img/profile-pic-01.jpg" alt="">
                                                    </div>
                                                </div>
                                                <div class="activity--toolbar">
                                                    <ul class="nav navbar-nav">
                                                       
                                                        <li><a href="#">Inspiration</a></li>
                                                        <li><a href="#">Like</a></li>
                                                        <li><a href="#">Comment</a></li>
                                                        <li><a href="#">Delete</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Activity Item End -->
                                        
                                    </li>
                                    <li>
                                        <!-- Activity Item Start -->
                                        <div class="activity--item">
                                            <div class="activity--avatar">
                                                <a href="member-activity-personal.html">
                                                    <img src="img/activity-img/avatar-07.jpg" alt="">
                                                </a>
                                            </div>

                                            <div class="activity--info fs--14">
                                                <div class="activity--header">
                                                    <p><a href="member-activity-personal.html">Anita J. Lilley</a> posted an update in the group <a href="group-home.html">Lens-bians Photography</a></p>
                                                </div>

                                                <div class="activity--meta fs--12">
                                                    <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                </div>

                                                <div class="activity--content">
                                                    <div class="gallery--embed" data-trigger="gallery_popup">
                                                        <ul class="nav AdjustRow">
                                                            <li>
                                                                <a href="img/activity-img/gallery-embed-01.jpg">
                                                                    <img src="img/activity-img/gallery-embed-01.jpg" alt="">
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a href="img/activity-img/gallery-embed-02.jpg">
                                                                    <img src="img/activity-img/gallery-embed-02.jpg" alt="">
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a href="img/activity-img/gallery-embed-03.jpg">
                                                                    <img src="img/activity-img/gallery-embed-03.jpg" alt="">
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a href="img/activity-img/gallery-embed-04.jpg" data-overlay="0.5">
                                                                    <img src="img/activity-img/gallery-embed-04.jpg" alt="">
                                                                    <span>24+ More</span>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Activity Item End -->
                                    </li>
                                    <li>
                                        <!-- Activity Item Start -->
                                        <div class="activity--item">
                                            <div class="activity--avatar">
                                                <a href="member-activity-personal.html">
                                                    <img src="img/activity-img/avatar-08.jpg" alt="">
                                                </a>
                                            </div>

                                            <div class="activity--info fs--14">
                                                <div class="activity--header">
                                                    <p><a href="member-activity-personal.html">Carl A. Toler</a> posted an update with his friend <a href="member-activity-personal.html">Susan J. Bounds</a></p>
                                                </div>

                                                <div class="activity--meta fs--12">
                                                    <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                </div>

                                                <div class="activity--content">
                                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Activity Item End -->
                                    </li>
                                    <li>
                                        <!-- Activity Item Start -->
                                        <div class="activity--item">
                                            <div class="activity--avatar">
                                                <a href="member-activity-personal.html">
                                                    <img src="img/activity-img/avatar-09.jpg" alt="">
                                                </a>
                                            </div>

                                            <div class="activity--info fs--14">
                                                <div class="activity--header">
                                                    <p><a href="member-activity-personal.html">Martina B. Scott</a> feeling happy with <a href="member-activity-personal.html">Eva C. Rucker</a> and <a href="#">5 more others</a></p>
                                                </div>

                                                <div class="activity--meta fs--12">
                                                    <p><i class="fa mr--8 fa-clock-o"></i>Yeasterday at 08:20 am</p>
                                                </div>

                                                <div class="activity--content">
                                                    <p>I was as big as I have ever been. I had a personal trainer and was working out. I was feeling good. I was muscular. I had never weighed more than 155 pounds.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Activity Item End -->
                                    </li>
                                </ul>
                                <!-- Activity Items End -->
                            </div>
                            <!-- Activity List End -->
                        </div>

                        <!-- Load More Button Start -->
                        <div class="load-more--btn pt--30 text-center">
                            <a href="#" class="btn btn-animate">
                                <span>See More Activities<i class="fa ml--10 fa-caret-right"></i></span>
                            </a>
                        </div>
                        <!-- Load More Button End -->
                    </div>
                    <!-- Main Content End -->
                    <?php
                    include'inc/sidebar-server.php';
                      ?>
                </div>
            </div>
        </section>
                                    </div>
                                    <!-- END PAGE CONTENT INNER -->
                                </div>
                            </div>
                            <!-- END PAGE CONTENT BODY -->
                            <!-- END CONTENT BODY -->
                        </div>
                        <!-- END CONTENT -->
                    <!-- END CONTAINER -->
                </div>
            </div>

        </div>  <!-- END Pagerow full height -->
                   <?php
                    include'inc/footer.php';
                   ?>
     </div>
      
               <!--[if lt IE 9]>
<script src="assets/global/plugins/respond.min.js"></script>
<script src="assets/global/plugins/excanvas.min.js"></script> 
<script src="assets/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
<!-- BEGIN CORE PLUGINS -->
        <script src="assets/global/plugins/jquery.min.js" type="text/javascript"></script>
  <!-- BEGIN CORE PLUGINS -->
        <script src="assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>

        <script src="assets/global/plugins/bootstrap-modal/js/bootstrap-modalmanager.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap-modal/js/bootstrap-modal.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap-markdown/lib/markdown.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js" type="text/javascript"></script>

        <script src="assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
       
        <!-- END CORE PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="assets/global/scripts/app.min.js" type="text/javascript"></script>
        <script src="assets/pages/scripts/ui-extended-modals.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="assets/layouts/layout3/scripts/layout.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
          <!-- ==== Main Script ==== -->
        <script src="js/plugins.min.js"></script>
        <script src="assets/pages/scripts/components-select2.min.js" type="text/javascript"></script>
        <script src="js/main.js"></script>
        
          
    </body>

</html>